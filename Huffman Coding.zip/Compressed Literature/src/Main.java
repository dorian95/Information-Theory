import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();
		CodingTree myTree;
		File file = new File("sawyr10.txt");
		System.out.println("name of the file" + file);
		StringBuilder sb = new StringBuilder();
		String encodedString;
		try 
		{
	
			Scanner scanner = new Scanner(file);
			
			//need to create a tree for each with
			// a non-zero count
			while (scanner.hasNextLine())
			{
				
				String stringRead = scanner.nextLine();
				sb.append(stringRead);
				sb.append("\r\n");
				
			}
			//System.out.println("STRING BUILDER " + sb.toString());
			myTree = new CodingTree(sb.toString());

			//encodedString = myTree.getEncoded();
			//bitString(encodedString, myTree);
			long endTime = System.currentTimeMillis();
			scanner.close();
			System.out.println("Time elapsed on encoding: " + (double) (endTime - startTime)/1000.0 +" s");
			//System.out.println("File read successfully");
		}
		
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		

	//}
	
	//testCodingTree();
	}

	public static void testCodingTree ()
	{
		CodingTree testTree = new CodingTree ("333333 caab44nnnnn");
		//System.out.println(testTree.myUniqueChars);
		System.out.println("minHeap " + testTree.minHeap.toString());	
		
	}
}
