/*
 * Nursultan Irgaliyev
 * TCSS 342 Assignment 3 Compressed Literature
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;


public class CodingTree {
	public List<Byte> bits;
	public HashMap <Character, Integer> myUniqueChars = new HashMap <Character, Integer> ();
	public PriorityQueue <Node> minHeap = new PriorityQueue <Node> ();
	private static HashMap <Character, String> myCodes = new HashMap <Character, String> ();
	private String original;
	private String encoded;
	
	private static int originalSize;
	//public HashMap<Character, StringBuilder> myCodes = new HashMap <Character, StringBuilder> ();

	public CodingTree(final String file) {
		Node root;
		countChar(file);
		original = file;
		createTrees();
      createSingleTree();
      createCodes(minHeap.poll(), "");
      //System.out.println(myCodes.toString());
     //createEncoded(original);
      createEncoded(file);
      originalSize = file.length();
     // System.out.println("originalSize " + originalSize);
   // System.out.println("ENCODED " + encoded.length()/8);
    bitString(encoded);
    
	}
	
	public void createTrees() 
	{
		for (char data : myUniqueChars.keySet())
		{
			Node temp = new Node (data, myUniqueChars.get(data));
			minHeap.add(temp);
		}
	}
	
	
	public void countChar (String file)
	{
		for (int i=0; i <file.length(); i++)
		{
			if (myUniqueChars.containsKey(file.charAt(i)))
			{
				myUniqueChars.put(file.charAt(i), myUniqueChars.get(file.charAt(i))+1);
			}
			else
			{
				myUniqueChars.put(file.charAt(i), 1);
			}

		}
		System.out.println("\n\t***number of unique characters : " + myUniqueChars.size());
	}
	
	public void createSingleTree ()
	{
		while (minHeap.size() >1)
		{
			//System.out.println("\n1st smallest: " + myPQ.peek().toString());
			Node node1 = minHeap.poll();
			Node node2 = minHeap.poll();
			int totalWeight = node1.frequency + node2.frequency;
			Node singleTree = new Node (totalWeight, node1, node2);
			//minHeap.offer(singleTree);
			minHeap.add(singleTree);
		}
	}
	
	public void createCodes (Node root, String code)
	{
		if (root.left == null && root.right == null)
		{
			myCodes.put(root.data, code);
		}
		else 
		{
			createCodes(root.left, code + "0");
			createCodes(root.right, code + "1");
		}
	}
	
	//public String createEncoded (String original)// HashMap <Character, String> map) 
	public void createEncoded (String original)
	{
		StringBuilder s = new StringBuilder();
		for (int i=0; i<original.length(); i++)
		{
				//s.append(map.get(original.charAt(i)));
				//char temp = original.charAt(i);
				s.append(myCodes.get(original.charAt(i)));
				//System.out.println(s.toString());
		}
		
		//return s.toString();
		
		encoded = s.toString();
		
	}
	
	/*
	public String decode(String bits) {
		
		String temp = new String();
		String dencoded = new String();
		
		for (int i = 0; i <bits.length(); i++) {
			temp += bits.charAt(i);
			Character ch = encoded.get(temp);
			if (ch != null && c!=0) {
				decoded = "";
			}
		}
		return encoded;
	}
	*/
	public static void bitString (String encoded) 
	{ 
		int rem = encoded.length()%8;
		if (rem != 0)
		{
			for (int i = 0; i < rem; i++)
			{
				encoded = encoded + "0";
			}
		}
		int it = encoded.length()/8;
		//System.out.println("IT = " + it);
		System.out.println("Original size = " + originalSize);
		double ratio = Math.round((it/(double) originalSize)* 100);
		System.out.println("Compression ratio: " + ratio + "%");
		FileOutputStream stream = null;
		try {
			stream = new FileOutputStream("compressed.txt");
		} catch (FileNotFoundException e) {
		
			e.printStackTrace();
		}
		byte [] tempArr = new byte [it];
		for (int i = 0; i < it; i++)
		{
			int temp = Integer.parseInt(encoded.substring(i*8, i*8 + 8));
			tempArr[i] = (byte) temp;
		}
		
		try {
			stream.write(tempArr);
		} catch (IOException e) {
	
			e.printStackTrace();
		}
		try(  PrintWriter out = new PrintWriter( "codes.txt")  ){
		    out.println(myCodes.toString());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}		
	}
	
	
	private class Node implements Comparable<Node>
	{
		private int frequency;
		private Node left;
		private Node right;
		private char data;
		
		public Node(char theData, int weight)
		{
			frequency = weight;
			data = theData;
			left = null;
			right = null;
		}
		
		public Node (int weight, Node theLeft, Node theRight)
		{
			frequency = weight;
			left = theLeft;
			right = theRight;
		}

		@Override
		public int compareTo(Node other) {

			return frequency - other.frequency;
//			
		}
		
		public String toString ()
		{
			String s ="";
			s = s + "char: " + data + " weight: " + frequency;
			return s;
		}
	}

	
}
